# Implementation record

The workspace began as an empty projectless directory, not an existing Git repository. No user branch or unrelated code was changed. Source, Xcode project, package, and deliverables are under outputs.

Protocol source correction: the generic design mentioned USB interface 2. OpenRazer's mouse path uses interface 0 for this PID. Hardware metadata read on interface 0 returned firmware 1.2 with valid checksum and matching transaction/class/command. The implementation pins the exact device VID/PID and interface 0.

Core TDD sequence: initial tests failed because protocol/effect types were absent; implementation then passed. Coordinator tests failed because StreamState was absent, then passed. Independent review found six substantive issues; fixes cover audio startup cancellation, diagnostics ownership/sleep cleanup, firmware reconnect monitoring, recovery rate persistence, double brightness, and stale frame completions. The double-brightness regression was observed failing before the fix and passing afterward. Lifecycle fixes were reviewed in code; their macOS integration paths still require manual user testing.

The first 300-second 25 Hz target test sent 6,890 frames with zero command errors and maximum USB latency 72.36 ms. Relative scheduling accumulated timer drift (~22.97 actual Hz). The scheduler was changed to monotonic absolute deadlines with missed-frame skipping. The final isolated soak delivered 7,500 validated frames in 300 seconds, zero errors, maximum USB latency 23.056 ms. Final OFF was acknowledged and brightness read back 0/255. See verification.md.

The user requested additional real CPU/audio/system testing after the initial handoff. CPU temperature is now implemented via a read-only experimental AppleSMC interface validated on the target Apple M4, with hottest-core selection, one-second caching, source/key labeling, and invalid-value rejection. Public stable per-CPU sensor access remains absent; the UI explicitly identifies this as experimental/private. Only metadata/read SMC actions are exposed. Real audio capture and system effect pipelines were then exercised with the built app, as detailed in verification.md. Login registration, visual output, pointer interaction, physical unplug, and real sleep/wake still require user observation.

No firmware flash, sensor polling-rate changes, button remapping, Accessibility permission, device seizing, or kernel extension is used. Ordinary effect commands and custom frames use volatile storage. Final test cleanup sends the firmware off command.
